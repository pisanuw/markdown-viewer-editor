#!/bin/bash
set -euo pipefail
FILE="$1"
RES_DIR="$2"

NAME=$(basename "$FILE")
# tr -d '\n' strips the line-wrapping macOS base64 adds (76-char limit)
# so the value fits in a single-line JS string literal
B64=$(base64 < "$FILE" | tr -d '\n')
NAME_JSON=$(python3 -c "import sys,json; print(json.dumps(sys.argv[1]))" "$NAME")
FILE_JSON=$(python3 -c "import sys,json; print(json.dumps(sys.argv[1]))" "$FILE")

TMPDIR=$(mktemp -d /tmp/md-editor-XXXXXX)
TMP="$TMPDIR/editor.html"

{
  echo '<script>'
  echo "window.__initialContent = '$B64';"
  echo "window.__initialFileName = $NAME_JSON;"
  echo "window.__initialFilePath = $FILE_JSON;"
  echo '</script>'
  cat "${RES_DIR}index.html"
} > "$TMP"

open "file://$TMP"
sleep 30 && rm -rf "$TMPDIR" &
